<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <body>
    @if($nome == "Miguel")
        <p>Bem-vindo, Miguel!</p>

    @else
        <p>Não conheço a pessoa que aqui está...</p>


    @endif
    </body>
</html>
